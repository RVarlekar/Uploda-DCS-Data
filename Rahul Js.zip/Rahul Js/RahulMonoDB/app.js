require("dotenv").config();

const express = require("express");
const app = express();
app.use(express.json());
const port = 5000;
const mongoose = require("mongoose");

const users = require("./user");

mongoose
.connect(process.env.MONGOURL)
.then(()=>console.log("MOngoDb Connect!"));


app.get("/", (req, res) => res.send("Hello World!"));
app.post("/registration", (req, res) => {
  const uname = req.body.username;
  const pass = req.body.password;
  const name = req.body.name;
  const age = req.body.age;
  const user = users.filter((u) => u.username === uname);

  if (user.length === 0) {
    return res.json({ data: "registration successfull" });
  } else {
    return res.json({ data: "username already taken. Please choose another" });
  }
});

app.listen(port, () => console.log(`server running on port 5000`));

app.post("/login", (req, res) => {
    const uname = req.body.username;
    const pass = req.body.password;
    const user = users.filter((u) => u.username === uname && u.password === pass);
  
    if (user.length === 0) {
      return res.json({ data: "wrong credentials! please try again." });
    } else {
      return res.json({ data: "login successfull" });
    }
  });
  // http://localhost:5000/list/?name=josh&age=25
  app.get("/list", (req, res) => {
    const name = req.query.name;
    const age = req.query.age;
  
    let userList = users.filter((u) => u.name === name && u.age > parseInt(age));
  
    if (userList.length === 0) {
      return res.json({ data: "user not found" });
    } else {
      return res.json({ data: userList });
    }
  });