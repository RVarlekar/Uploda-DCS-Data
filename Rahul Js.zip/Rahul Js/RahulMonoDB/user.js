const users = [
    {
      username: "user1",
      password: "pass1",
      name: "josh",
      age: 15,
    },
    {
      username: "user2",
      password: "pass2",
      name: "josh",
      age: 25,
    },
    {
      username: "user3",
      password: "pass3",
      name: "karen",
      age: 22,
    },
    {
      username: "user4",
      password: "pass4",
      name: "josh",
      age: 40,
    },
    {
      username: "user5",
      password: "pass5",
      name: "amy",
      age: 15,
    },
    {
      username: "user9",
      password: "pass9",
      name: "jake",
      age: 20,
    }
  ];
  
  module.exports = users;